import React from "react"
import Image from "next/image"

const Header =()=>{

    return (

        <>
        <div className="header-image">
        <Image src="/background-1.jpg" layout="fill" objectFit="cover"/>
        </div>
        </>

    )
}

export default Header