
import FooterCopyright from "./footer-copyright"
import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },
  paper: {
    padding: theme.spacing(2),
    textAlign: 'center',
    color: theme.palette.text.secondary,
  },
}));

export default function FullWidthGrid() {
  const classes = useStyles();

  return (
      <>
      <div className="footer-background">
      <div className="container">
    <div className={classes.root}>
      <Grid container spacing={1} style={{textAlign: "center"}}>
      <Grid item lg={6} md={6} xs={12} sm={12} style={{padding: 2 + "rem"}}>
      <div style={{color: "#000", textAlign: "left", fontSize: 1.5 + "rem"}}>
        <a href="/">The Logo</a>
      </div>
        </Grid>
        <Grid item lg={6} md={6} xs={12} sm={12} style={{padding: 2 + "rem"}}>

   
        </Grid>
        <Grid item lg={3} md={3} xs={12} sm={12} style={{padding: 2 + "rem"}}>
         <p> Text Goes Here </p>
        </Grid>
        <Grid item lg={3} md={3} xs={12} sm={12} style={{padding: 2 + "rem"}}>
         <p> Text Goes Here </p>
        </Grid>
        <Grid item lg={3} md={3} xs={12} sm={12} style={{padding: 2 + "rem"}}>
         <p> Text Goes Here </p>
        </Grid>
        <Grid item lg={3} md={3} xs={12} sm={12} style={{padding: 2 + "rem"}}>
         <p> Text Goes Here </p>
        </Grid>
      </Grid>
    </div>
    <FooterCopyright/>
    </div>
    </div>
    </>
  );
}