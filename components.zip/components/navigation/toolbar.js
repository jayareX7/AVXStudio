import React from "react";
import Toggle from "./toggle";
import {
  AppBar,
  Paper,
  Tabs,
  Tab,
  Popper,
  MenuList,
  MenuItem
} from "@material-ui/core";



const toolbar = props => (
  <header className="toolbar">
    <nav className="toolbar_navigator">
      <div />
      <div className="toggle-btn">
        <Toggle click={props.drawerToggleClickHandler} />
      </div>
      <div className="toolbar_logo">
        <a href="/">The Logo</a>
      </div>
      <div className="spacer" />
      <div className="toolbar_navigation-items">
      <MyMenu />
      </div>
    </nav>
  </header>
);








const items = [
  { pathName: "/test", label: "Test 1" },
  { pathName: "/test", label: "Test 2" },
  { pathName: "/test", label: "Test 3" }
];

const subItems = ["Item 1", "Item 2", "Item 3"];



export function MyMenu () {

  const [state, setState] = React.useState({
    value: 0, // Indicator position
    open: false, // is Dropdown open
    anchorEl: null
  });
  const { anchorEl, open } = state;

  const handleMenuOpen = (index, event) => {
    const { currentTarget } = event;
    setState({
      open: true, // is Dropdown open
      anchorEl: currentTarget,
      value: index // Indicator position
    });
    console.log(currentTarget);
  };

  const handleMenuClose = () => {
    setState({
      value: 0, // Indicator position
      open: false, // is Dropdown open
      anchorEl: null
    });
  };

  return (
    <div onMouseLeave={() => handleMenuClose()}>
      <AppBar position="static">
        <Paper>
          <Tabs
            value={state.value}
            centered
          >
            {items.map((item, index) => (
              <Tab
                key={index}
                onMouseEnter={(event) => handleMenuOpen(index, event)}
                //data-key={index}
                label={item.label}
                aria-owns={open ? "menu-list-grow" : undefined}
                aria-haspopup={"true"}
              />
            ))}
          </Tabs>
          <Popper open={open} anchorEl={anchorEl} id="menu-list-grow">
            <Paper>
              <MenuList>
                {subItems.map((item, index) => (
                  <MenuItem key={index} onClick={() => handleMenuClose()}>
                    {item}
                  </MenuItem>
                ))}
              </MenuList>
            </Paper>
          </Popper>
        </Paper>
      </AppBar>
    </div>
  );



};



export default toolbar;




